# IBD Evidence Assistant v2 (ibd-evidence-assistant-v2)

Installed form of the agent designed end-to-end by **OMA** (`opl-meta-agent`) in FoundryRun
`ibd-oma-create-33`.

## Provenance

- FoundryRun: `ibd-oma-create-33` (6/6 design stages completed, 9 stage attempts, 0 failures)
- Blueprint: `ibd-evidence-assistant-design-ibd-agent-20260920-33` (`sha256:4de37909bf26c2a2ba12b2d66182e4e31939ab09f1bc1a49edf614117ac5d92d`)
- Candidate: `sha256:3ff53f8a58b7c217e2aae8a796d8e592f5efbd7d2f4f5a656517aebf4ead60af` — 36 indexed files
- Stages: answer-from-current-evidence
- Actions: answer-ibd-evidence-question

## What was copied vs. authored

Byte-identical from the run33 candidate: `agent/`, `content/`, `contracts/` (except the two files
below), `runtime/`, `agent-blueprint.json`, `candidate-index.json`.

Authored installable shell (not produced by the pipeline yet): `opl-package.json`,
`plugin.json`, `.codex-plugin/plugin.json`, `.agents/plugins/marketplace.json`,
`skills/ibd-evidence-assistant-v2/SKILL.md`, `contracts/domain_descriptor.json` (OMA body +
`standard_agent_interface` + `design_provenance`),
`contracts/opl_domain_manifest_registration.json`, `contracts/opl_agent_package_manifest.json`.

## Authority

OPL owns physical materialisation, file digests and the final build receipt. This package carries
no qualification or activation receipt; it is a construction-side artefact only.
