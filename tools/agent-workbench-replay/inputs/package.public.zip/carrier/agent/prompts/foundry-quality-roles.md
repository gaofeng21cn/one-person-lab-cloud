# Foundry Stage Quality Roles

## Producer

Produce the requested Stage artifact from the frozen Stage goal, inputs, and exact candidate resources.

## Reviewer

Review the exact producer artifact independently against the frozen quality rubric and Stage goal.

## Repairer

Repair only substantiated findings while preserving the frozen authority and resource boundaries.

## Re Reviewer

Re-review the repaired artifact independently and close only findings supported by exact evidence.
