# Foundry Generated Agent Quality Rubric

- The result satisfies the frozen Stage goal and declared artifact contract.
- Claims are supported by the exact candidate resources and input artifacts.
- The result does not exceed target-owner authority or mutate Foundry state.
- Remaining quality debt, safety concerns, and owner decisions are explicit.
